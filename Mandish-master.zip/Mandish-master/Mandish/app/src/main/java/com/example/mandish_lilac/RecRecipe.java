package com.example.mandish_lilac;

public class RecRecipe {
    /*
   작성자: 김강민
   내용: 사용자가 추천한 레시피를 담을 Class
    */
    private int recipe_code;

    public int getRecipe_code() {
        return recipe_code;
    }

    public void setRecipe_code(int recipe_code) {
        this.recipe_code = recipe_code;
    }
}
