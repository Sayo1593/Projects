package com.example.mandish_lilac;

import java.util.ArrayList;

public interface IDataCallback {

    void onFragmentCreated( ArrayList<String> listData);
}