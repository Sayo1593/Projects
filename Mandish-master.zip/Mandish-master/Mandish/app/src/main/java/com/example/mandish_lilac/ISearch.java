package com.example.mandish_lilac;

public interface ISearch {

    void onTextQuery(String text);
}