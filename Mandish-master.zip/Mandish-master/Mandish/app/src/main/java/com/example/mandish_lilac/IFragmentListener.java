package com.example.mandish_lilac;

public interface IFragmentListener {
    void addiSearch(ISearch iSearch);

    void removeISearch(ISearch iSearch);
}
