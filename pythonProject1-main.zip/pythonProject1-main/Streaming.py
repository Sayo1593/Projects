f = open("Buy.txt", "r")
while True:
    st = f.readline().split()
    if st == []:
        break
    print("코인 " + st[0] + "를 " + st[1] + "원에 " + st[2] + "개 만큼 매수 주문하였습니다.")
